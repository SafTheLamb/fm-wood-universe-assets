return
{
  width = 66,
  height = 774,
  shift = util.by_pixel( 0.0, 15.0),
  line_length = 16,
  filenames = {
    "-1.png",
    "-2.png",
  },
  lines_per_file = 4,
}

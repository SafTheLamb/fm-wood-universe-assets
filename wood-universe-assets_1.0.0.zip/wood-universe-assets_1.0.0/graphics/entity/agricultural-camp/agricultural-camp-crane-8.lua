return
{
  width = 44,
  height = 78,
  shift = util.by_pixel( 0.0, 0.0),
  line_length = 16,
}

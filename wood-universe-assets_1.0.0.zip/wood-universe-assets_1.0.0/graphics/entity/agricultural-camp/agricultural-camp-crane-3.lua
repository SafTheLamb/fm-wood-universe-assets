return
{
  width = 82,
  height = 210,
  shift = util.by_pixel( 0.0, -8.5),
  line_length = 16,
}

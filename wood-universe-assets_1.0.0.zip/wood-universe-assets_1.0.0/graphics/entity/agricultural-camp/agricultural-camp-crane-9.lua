return
{
  width = 26,
  height = 148,
  shift = util.by_pixel( 0.5, 0.0),
  line_length = 1,
}

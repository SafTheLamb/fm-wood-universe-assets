return
{
  width = 72,
  height = 144,
  shift = util.by_pixel( 0.0, -15.0),
  line_length = 16,
}

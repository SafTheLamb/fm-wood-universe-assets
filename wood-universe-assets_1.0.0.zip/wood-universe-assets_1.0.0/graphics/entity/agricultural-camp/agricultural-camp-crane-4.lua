return
{
  width = 100,
  height = 128,
  shift = util.by_pixel( 0.0, 4.0),
  line_length = 16,
}

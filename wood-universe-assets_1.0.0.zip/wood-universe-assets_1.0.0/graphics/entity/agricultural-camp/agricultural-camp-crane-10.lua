return
{
  width = 42,
  height = 62,
  shift = util.by_pixel( -0.5, 0.5),
  line_length = 1,
}

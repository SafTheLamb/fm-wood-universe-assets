return
{
  width = 64,
  height = 628,
  shift = util.by_pixel( -1.0, 11.5),
  line_length = 16,
  filenames = {
    "-1.png",
    "-2.png",
  },
  lines_per_file = 4,
}

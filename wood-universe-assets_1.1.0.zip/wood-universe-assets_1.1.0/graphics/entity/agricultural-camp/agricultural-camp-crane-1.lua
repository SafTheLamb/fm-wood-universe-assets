return
{
  width = 406,
  height = 330,
  shift = util.by_pixel( 0.0, -4.5),
  line_length = 8,
  filenames = {
    "-1.png",
    "-2.png",
  },
  lines_per_file = 8,
}
